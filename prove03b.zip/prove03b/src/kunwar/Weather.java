package kunwar;

public class Weather {
    int id;
    String main;
    String descriptionn;
    String icon;

//    Weather(int id, String main, String description){
//        this.descriptionn = description;
//        this.id = id;
//        this.main = main ;
//    }


    public String getDescriptionn() {
        return descriptionn;
    }
}
